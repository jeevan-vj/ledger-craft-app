Accountant close pack
Kauri Two Period Web Limited
2026-11-01 to 2026-11-30
Accrual / NZD
Generated 2027-05-01T00:00:00.000Z

Canonical server reports and exact decimal amounts; CSVs are spreadsheet-safe.
Reports include posted journals only. Original GST records retain their saved settings, source audits and filing references.
This archive neither closes the books nor submits GST to IRD. Use manifest.json warnings and the retained records when reviewing readiness.
Member checksums exclude manifest.json itself.
