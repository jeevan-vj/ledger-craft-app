Accountant close pack
Kauri Self Service Mobile Limited
2026-10-01 to 2026-10-31
Accrual / NZD
Generated 2026-11-08T07:22:17.873Z

Canonical server reports and exact decimal amounts; CSVs are spreadsheet-safe.
Reports include posted journals only. Original GST records retain their saved settings, source audits and filing references.
This archive neither closes the books nor submits GST to IRD. Use manifest.json warnings and the retained records when reviewing readiness.
Member checksums exclude manifest.json itself.
